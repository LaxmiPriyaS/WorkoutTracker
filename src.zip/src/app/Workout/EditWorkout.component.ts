import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from "./../shared.service";


@Component({
  selector: 'app-editworkout',
  templateUrl: './EditWorkout.component.html',
  styles: [],
  providers:[SharedService] 
})
export class EditWorkoutComponent implements OnInit {
  
  
  editWorkoutTitle: string = "";
editWorkoutNote: string = "";
selectCategory: string = "";

constructor(private router: Router,private _sharedService: SharedService) { }

  ngOnInit() {
  }
cancelEditWorkout()
{
	this.router.navigate(['/viewWorkout']); 
}
CreateWorkoutFunc() {  
  this._sharedService.EditWorkout(this);
    
 }
}