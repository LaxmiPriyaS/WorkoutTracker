import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from "./../shared.service";

@Component({
  selector: 'app-endworkout',
  templateUrl: './EndWorkout.component.html',
  styles: [],
  providers:[SharedService] 
})
export class EndWorkoutComponent implements OnInit {
endDate:Date;

constructor(private router: Router) { }


  ngOnInit() {
  }
	cancelEditWorkout()
	{
		this.router.navigate(['/viewWorkout']); 
	}
 
}